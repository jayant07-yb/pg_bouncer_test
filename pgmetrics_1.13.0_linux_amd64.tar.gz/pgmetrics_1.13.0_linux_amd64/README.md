
`pgmetrics` collects and displays various information and statistics from a
running PostgreSQL server to aid in troubleshooting, monitoring and automation.

For more information, see [pgmetrics.io](https://pgmetrics.io).

pgmetrics is developed and maintained by [RapidLoop](https://rapidloop.com).
Follow us on Twitter at [@therapidloop](https://twitter.com/therapidloop/).

